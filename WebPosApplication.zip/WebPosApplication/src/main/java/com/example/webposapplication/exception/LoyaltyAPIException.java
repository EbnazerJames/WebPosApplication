// LoyaltyAPIException.java
package com.example.webposapplication.exception;

import org.springframework.http.HttpStatus;

public class LoyaltyAPIException extends RuntimeException {

    private final HttpStatus httpStatus;

    public LoyaltyAPIException(String message, Throwable cause) {
        super(message, cause);
        this.httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;
    }

    public LoyaltyAPIException(String message, HttpStatus httpStatus) {
        super(message);
        this.httpStatus = httpStatus;
    }

    public HttpStatus getHttpStatus() {
        return httpStatus;
    }
}
