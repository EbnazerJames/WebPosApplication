// CatalogueController.java
package com.example.webposapplication.catalogue;

import com.example.webposapplication.exception.LoyaltyAPIException;
import com.example.webposapplication.service.LoyaltyAPIService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CatalogueController {

    @Autowired
    private LoyaltyAPIService loyaltyAPIService;

    @GetMapping("/catalogue")
    public ResponseEntity<String> getGiftCardCatalog() {
        try {
            return loyaltyAPIService.getGiftCardCatalog();
        } catch (LoyaltyAPIException e) {
            return ResponseEntity.status(e.getHttpStatus()).body(e.getMessage());
        }
    }
}
