// AuthController.java
package com.example.webposapplication.auth;

import com.example.webposapplication.service.LoyaltyAPIService;
import com.example.webposapplication.exception.LoyaltyAPIException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AuthController {

    @Autowired
    private LoyaltyAPIService loyaltyAPIService;

    @PostMapping("/authenticate")
    public ResponseEntity<String> authenticateUser(@RequestBody AuthRequest authRequest) {
        try {
            return loyaltyAPIService.authenticateUser(authRequest.getUsername(), authRequest.getPassword(), authRequest.getSecret());
        } catch (LoyaltyAPIException e) {
            return ResponseEntity.status(e.getHttpStatus()).body(e.getMessage());
        }
    }
}
