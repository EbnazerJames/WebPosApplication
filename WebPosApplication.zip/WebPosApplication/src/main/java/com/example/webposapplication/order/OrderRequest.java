// OrderRequest.java
package com.example.webposapplication.order;

public class OrderRequest {

    private String giftCardId;
    private int quantity;

    // getters and setters

    public String getGiftCardId() {
        return giftCardId;
    }

    public void setGiftCardId(String giftCardId) {
        this.giftCardId = giftCardId;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    
}
