/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.example.webposapplication;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 *
 * @author user1
 */
@SpringBootApplication
public class WebPosApplication {
    public static void main(String[] args) {
        SpringApplication.run(WebPosApplication.class, args);
    }
}
