// OrderController.java
package com.example.webposapplication.order;

import com.example.webposapplication.exception.LoyaltyAPIException;
import com.example.webposapplication.service.LoyaltyAPIService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class OrderController {

    @Autowired
    private LoyaltyAPIService loyaltyAPIService;

    @PostMapping("/placeOrder")
    public ResponseEntity<String> placeOrder(@RequestBody OrderRequest orderRequest) {
        try {
            return loyaltyAPIService.placeOrder(orderRequest);
        } catch (LoyaltyAPIException e) {
            return ResponseEntity.status(e.getHttpStatus()).body(e.getMessage());
        }
    }
}
